import 'package:flutter/material.dart';

import 'foods/chickenrice_page.dart';
import 'foods/padthai_page.dart';
import 'foods/sweetbasil_page.dart';
import 'foods/radna_page.dart';
import 'snacks/brownie_page.dart';
import 'snacks/lce_cream_page.dart';
import 'snacks/cake_page.dart';

void main() {
  runApp(FoodApp());
}

class FoodApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'chiaranai App',
      routes: {
        '/chickenrice': (context) => NoodlePage(),
        '/padthai': (context) => SomTumPage(),
        '/sweetbasil': (context) => KapraoPage(),
        '/radna': (context) => SeafoodPage(),
        '/brownie': (context) => BingsuPage(),
        '/lcecream': (context) => DurianCakePage(),
        '/cake': (context) => KanomBuengPage(),
      },
      home: FoodMenuPage(),
    );
  }
}

class FoodMenuPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("รายการอาหารคาว & อาหารหวาน"),
        backgroundColor: const Color.fromARGB(255, 69, 186, 233),
      ),

      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                "อาหารคาว",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),

            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                buildMenu(context, "กะเพรา", "assets/aaaa.png", "/sweetbasil"),
                buildMenu(
                  context,
                  "ข้าวมันไก่",
                  "assets/ffff.jpg",
                  "/chickenrice",
                ),
                buildMenu(context, "ราดหน้า", "assets/hhhh.jpg", "/radna"),
                buildMenu(context, "ผัดไทย", "assets/dddd.png", "/padthai"),
              ],
            ),

            const SizedBox(height: 20),

            const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                "อาหารหวาน",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),

            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                buildMenu(context, "บราวนี่", "assets/bbbb.png", "/brownie"),
                buildMenu(context, "ไอศรีม", "assets/cccc.png", "/lcecream"),
                buildMenu(context, "เค้ก", "assets/kkkk.png", "/cake"),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget buildMenu(
    BuildContext context,
    String title,
    String img,
    String route,
  ) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Card(
        elevation: 4,
        margin: const EdgeInsets.all(8),
        child: Column(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(img, fit: BoxFit.cover),
              ),
            ),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }
}
