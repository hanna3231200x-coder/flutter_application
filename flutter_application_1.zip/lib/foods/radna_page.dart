import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MaterialApp(home: SeafoodPage()));
}

class SeafoodPage extends StatefulWidget {
  const SeafoodPage({super.key});

  @override
  State<SeafoodPage> createState() => _SeafoodPageState();
}

class _SeafoodPageState extends State<SeafoodPage> {
  late YoutubePlayerController _ytController;

  // พิกัดร้าน
  final double shopLatitude = 18.29077;
  final double shopLongitude = 99.49261;

  // พิกัดผู้ใช้
  double? currentLat;
  double? currentLng;
  double distance = 0;
  String travelTime = '';

  final MapController _mapController = MapController();
  List<LatLng> routePoints = [];

  // ใส่ API Key ของคุณ
  final String orsApiKey =
      "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6ImZmYTVkY2ZiYzY4ODQ0ZDI5YjBhZjI0YTIzYTYxMDY2IiwiaCI6Im11cm11cjY0In0=";

  @override
  void initState() {
    super.initState();
    const videoUrl = 'https://www.youtube.com/watch?v=qGPCuyJxQWg';
    final videoId = YoutubePlayer.convertUrlToId(videoUrl);

    _ytController = YoutubePlayerController(
      initialVideoId: videoId ?? '',
      flags: const YoutubePlayerFlags(autoPlay: false, mute: false),
    );
  }

  @override
  void dispose() {
    _ytController.dispose();
    super.dispose();
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _showMessage("กรุณาเปิด GPS / Location");
      return;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever) {
      _showMessage("กรุณาเปิดสิทธิ์ Location ใน Settings");
      return;
    }

    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    setState(() {
      currentLat = position.latitude;
      currentLng = position.longitude;
      distance =
          Geolocator.distanceBetween(
            currentLat!,
            currentLng!,
            shopLatitude,
            shopLongitude,
          ) /
          1000;
    });

    _mapController.move(LatLng(currentLat!, currentLng!), 15);
    await _fetchRoute();
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _fetchRoute() async {
    if (currentLat == null || currentLng == null) return;

    final url = Uri.parse(
      'https://api.openrouteservice.org/v2/directions/driving-car/geojson',
    );
    final body = jsonEncode({
      "coordinates": [
        [currentLng!, currentLat!],
        [shopLongitude, shopLatitude],
      ],
    });

    final response = await http.post(
      url,
      headers: {"Authorization": orsApiKey, "Content-Type": "application/json"},
      body: body,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final coords = data['features'][0]['geometry']['coordinates'] as List;
      final summary = data['features'][0]['properties']['summary'];

      setState(() {
        routePoints = coords.map((c) => LatLng(c[1], c[0])).toList();
        travelTime = "${(summary['duration'] / 60).toStringAsFixed(0)} นาที";
      });
    } else {
      _showMessage("ไม่สามารถดึงเส้นทางได้");
    }
  }

  @override
  Widget build(BuildContext context) {
    final shopPoint = LatLng(shopLatitude, shopLongitude);

    return Scaffold(
      appBar: AppBar(
        title: const Text("ราดหน้า"),
        backgroundColor: const Color.fromARGB(255, 18, 129, 8),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "วัตถุดิบ:",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const Text(
              "- หมู\n- ผัก\n- แป้งข้าวเจ้า\n- พริก\n- น้ำมะนาว\n- น้ำปลาและน้ำตาล",
            ),
            const SizedBox(height: 10),
            const Text(
              "วิธีทำ:",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const Text(
              "1. ตั้งหม้อต้มน้ำใส่เครื่องปรุงและแป้งข้าวเจ้า\n2. ลวกหมูลวกเส้น\n3. ตักเสิร์ฟ",
            ),
            const SizedBox(height: 20),
            YoutubePlayer(
              controller: _ytController,
              showVideoProgressIndicator: true,
            ),
            const SizedBox(height: 30),
            const Text(
              "พิกัดร้านอาหาร:",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Text("Latitude: $shopLatitude"),
            Text("Longitude: $shopLongitude"),
            const SizedBox(height: 20),
            const Text(
              "แผนที่ร้านอาหาร:",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 300,
              child: FlutterMap(
                mapController: _mapController,
                options: MapOptions(center: shopPoint, zoom: 14),
                children: [
                  TileLayer(
                    urlTemplate:
                        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                    subdomains: const ['a', 'b', 'c'],
                  ),
                  MarkerLayer(
                    markers: [
                      Marker(
                        point: shopPoint,
                        width: 40,
                        height: 40,
                        builder: (_) => const Icon(
                          Icons.location_on,
                          color: Colors.red,
                          size: 40,
                        ),
                      ),
                      if (currentLat != null && currentLng != null)
                        Marker(
                          point: LatLng(currentLat!, currentLng!),
                          width: 40,
                          height: 40,
                          builder: (_) => const Icon(
                            Icons.my_location,
                            color: Colors.blue,
                            size: 40,
                          ),
                        ),
                    ],
                  ),
                  if (routePoints.isNotEmpty)
                    PolylineLayer(
                      polylines: [
                        Polyline(
                          points: routePoints,
                          color: Colors.blue,
                          strokeWidth: 4,
                        ),
                      ],
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "ตำแหน่งปัจจุบันของคุณ:",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(
              currentLat == null
                  ? "ยังไม่ได้อ่านพิกัด"
                  : "Lat: $currentLat\nLng: $currentLng",
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _getCurrentLocation,
              child: const Text("อ่านพิกัดปัจจุบัน"),
            ),
            const SizedBox(height: 10),
            Text(
              "ระยะทางจากคุณถึงร้าน: ${distance.toStringAsFixed(2)} กม.",
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            if (travelTime.isNotEmpty)
              Text(
                "เวลาเดินทางโดยรถยนต์: $travelTime",
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
